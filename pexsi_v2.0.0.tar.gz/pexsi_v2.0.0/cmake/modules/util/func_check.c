void FUNC_NAME();
int main() {
  FUNC_NAME();
  return 0;
}
