%PEXSI Developer's Documentation           {#mainpage}
================================

The documentation for the C-compatible API routines are in
`c_pexsi_interface.h`.

